"""Default init. Carry on.

.. moduleauthor:: Ryszard Cetnarski <cetnarski.ryszard@gmail.com.com>

"""
from . import Anova 
from . import CrossCorrelate 
from . import Normalize 
from . import Trends
from . import Explore
