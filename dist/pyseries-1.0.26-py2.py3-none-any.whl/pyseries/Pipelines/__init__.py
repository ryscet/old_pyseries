"""Default init. Carry on.

.. moduleauthor:: Ryszard Cetnarski <cetnarski.ryszard@gmail.com.com>

"""

from . import AnalyzeRest
from . import AnalyzeSsvep