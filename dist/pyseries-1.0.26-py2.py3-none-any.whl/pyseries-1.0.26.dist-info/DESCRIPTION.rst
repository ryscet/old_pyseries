Developed for analysis of EEG recordings. Targeted for neuro and cognitive science academics looking for a quick start into EEG data analysis with python.


