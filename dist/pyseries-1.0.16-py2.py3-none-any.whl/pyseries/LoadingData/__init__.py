"""Default init. Carry on.

.. moduleauthor:: Ryszard Cetnarski <cetnarski.ryszard@gmail.com.com>

"""

from . import Read_edf as read_edf
from . import ReadData as read_mat
