"""Default init. Carry on.

.. moduleauthor:: Ryszard Cetnarski <cetnarski.ryszard@gmail.com.com>

"""
__all__ = ['Analysis', 'LoadingData', 'Preprocessing']